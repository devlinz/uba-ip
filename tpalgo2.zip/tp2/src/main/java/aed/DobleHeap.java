
public class DobleHeap<T> {
    private class Handle {
        T datos;
        int otroIndice;
    }

    private Heap<Handle> heap1;
    private Heap<Handle> heap2;

    public DobleHeap<T>(T[] iniciales, Comparator<T> comparador1, Comparator<T> comparador2) {
        Handles[] handles = convertirEnHandles(iniciales)
        heap1 = new Heap<Handle>(handles,comparador1);
        heap2 = new Heap<Handle>(handles,comparador2);
    }
}