package aed;

import java.util.ArrayList;

public class BestEffort {
    //Completar atributos privados
    private ArrayList<Ciudad> ciudades;
    private DobleHeap<Traslado> t;

    private int superavitMax;
    private ArrayList<Integer> gananciasMaximas; 
    private ArrayList<Integer> perdidasMaximas; 
    private int trasladosDespachados;
    private int gananciasGlobales;

    public BestEffort(int cantCiudades, Traslado[] traslados){
        // Implementar
    }

    public void registrarTraslados(Traslado[] traslados){
        // Implementar
    }

    public int[] despacharMasRedituables(int n){
        tras = t.desencolarMaxUno()
        return null;
    }

    public int[] despacharMasAntiguos(int n){
        tras = t.desencolarMaxDos()
        return null;
    }

    public int ciudadConMayorSuperavit(){
        return superavitMax;
    }

    public ArrayList<Integer> ciudadesConMayorGanancia(){
        return gananciasMaximas;
    }

    public ArrayList<Integer> ciudadesConMayorPerdida(){
        return perdidasMaximas;
    }

    public int gananciaPromedioPorTraslado(){
        return (gananciasGlobales / trasladosDespachados);
    }
    
}
