package aed;

public class Traslado {
    
    int id;
    int origen;
    int destino;
    int gananciaNeta;
    int timestamp;

    public Traslado(int id, int origen, int destino, int gananciaNeta, int timestamp){
        this.id = id;
        this.origen = origen;
        this.destino = destino;
        this.gananciaNeta = gananciaNeta;
        this.timestamp = timestamp;
    }
}

public class Ciudad {
    
    int ganancia;
    int perdida;

    public int superavit(){
        return ganancia - perdida;
    }

    public Ciudad(int gan, int per){
        this.ganancia = gan;
        this.perdida = per;
    }
}

